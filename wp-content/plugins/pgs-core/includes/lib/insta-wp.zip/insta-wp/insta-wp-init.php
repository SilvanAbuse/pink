<?php
/**
 * Instagram WP init file.
 *
 * @package Instagram WP
 */

require_once trailingslashit( PGSCORE_PATH ) . 'includes/lib/insta-wp/class-insta-wp.php';
require_once trailingslashit( PGSCORE_PATH ) . 'includes/lib/insta-wp/class-insta-wp-api.php';
